# Unattended SDR Sensor Runtime (C++20)

A low-latency, deterministic real-time C++20 runtime engine designed for continuous **2.4 MSPS** Software-Defined Radio (SDR) and high-rate sensor stream ingestion. Engineered to eliminate dynamic allocations on the hot path, prevent cache-line false sharing, isolate real-time threads from OS jitter, and expose non-blocking health/telemetry metrics over POSIX shared memory.

## Architectural Highlights

* **Zero-Allocation Hot Path**: Pre-allocates ring buffer capacity and telemetry structures at startup; no `new`, `malloc`, or blocking I/O occurs inside real-time acquisition or DSP worker loops.
* **Lock-Free SPSC Ring Buffers (`SpscRingBuffer<T, Capacity>`)**: Single-Producer Single-Consumer queue using `alignas(64)` cache-line padding on `head_` and `tail_` atomics and explicit `std::memory_order_acquire` / `std::memory_order_release` semantics.
* **Real-Time Thread Scheduling & Core Pinning**: Configures `SCHED_FIFO` priorities and pins worker threads to dedicated logical CPU cores via `pthread_setaffinity_np` to reduce context-switch jitter.
* **Zero-Copy Shared Memory Telemetry (`TelemetryShm`)**: Publishes ring buffer depth, drop counts, sample rate metrics, and thread heartbeats to `/dev/shm/sdr_runtime_telemetry` so diagnostic/monitoring tools can inspect state without contending with the hot path.
* **Supervisor Watchdog**: Monitors monotonic heartbeats from real-time worker threads and flags stalled threads or buffer overruns in shared memory.

## Directory Layout

```text
sdr-sensor-runtime/
├── Makefile
├── README.md
├── include/
│   └── sdr_runtime/
│       ├── iq_sample.hpp
│       ├── spsc_ring_buffer.hpp
│       ├── rt_thread.hpp
│       ├── telemetry_shm.hpp
│       └── watchdog.hpp
├── src/
│   ├── main.cpp
│   ├── rt_thread.cpp
│   ├── telemetry_shm.cpp
│   └── watchdog.cpp
└── tests/
    └── benchmark_spsc.cpp
```

## Building & Running

```bash
# Release build
make

# Run runtime (note: SCHED_FIFO may require CAP_SYS_NICE or sudo on Linux)
./bin/sdr_runtime --duration-sec 5 --sample-rate 2400000

# Build and run SPSC throughput/latency benchmark
make bench
./bin/benchmark_spsc

# ThreadSanitizer & AddressSanitizer/UBSan verification
make tsan
./bin/benchmark_spsc_tsan
```

## Verification & Profiling Notes

* **Thread Safety**: `make tsan` instruments atomic and shared memory operations under ThreadSanitizer.
* **Memory Hygiene**: Run `valgrind --leak-check=full ./bin/sdr_runtime --duration-sec 1` (without `SCHED_FIFO` if running unprivileged) to confirm zero leaks.
* **Hardware Counters**: Use `perf stat -e cache-misses,context-switches,cpu-migrations ./bin/benchmark_spsc` to measure cache behavior and thread migration.
